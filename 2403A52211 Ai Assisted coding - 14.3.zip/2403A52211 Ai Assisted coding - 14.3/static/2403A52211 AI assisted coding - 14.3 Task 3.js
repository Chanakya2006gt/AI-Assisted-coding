document.getElementById("login-form").addEventListener("submit", function(event) {
    event.preventDefault();

    const usernameInput = document.getElementById("username");
    const passwordInput = document.getElementById("password");
    const loginMessage = document.getElementById("login-message");
    const studentDetails = document.getElementById("student-details");

    const username = usernameInput.value;
    const password = passwordInput.value;

    fetch('/login', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ username: username, password: password }),
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            loginMessage.textContent = data.message;
            loginMessage.style.color = "green";

            // Hide login form
            document.getElementById("login-section").style.display = "none";

            // Show student details
            studentDetails.style.display = "block";

            // Dynamically update details
            document.getElementById("student-name").textContent = data.username;
            document.getElementById("student-id").textContent = data.student_id;
            document.getElementById("student-program").textContent = data.program;
            document.getElementById("student-email").textContent = data.email;

            alert("Login Successful! Welcome, " + data.username + "!");
        } else {
            loginMessage.textContent = data.message;
            loginMessage.style.color = "red";
        }
    })
    .catch((error) => {
        console.error('Error:', error);
        loginMessage.textContent = "An error occurred during login.";
        loginMessage.style.color = "red";
    });
});
