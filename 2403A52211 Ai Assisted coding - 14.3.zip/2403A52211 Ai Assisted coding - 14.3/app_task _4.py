from flask import Flask, render_template, request, jsonify

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('2403A52211 AI assisted coding - 14.3 Task 1.html')

@app.route('/login', methods=['POST'])
def login():
    data = request.get_json()
    username = data.get('username')
    password = data.get('password')

    # Hardcoded credentials for demonstration
    if username == "student" and password == "password123":
        return jsonify({
            "success": True,
            "message": "Login successful!",
            "username": username,
            "student_id": "S12345",
            "program": "Computer Science",
            "email": f"{username}@example.com"
        })
    else:
        return jsonify({
            "success": False,
            "message": "Invalid username or password."
        })

if __name__ == '__main__':
    app.run(debug=True)
